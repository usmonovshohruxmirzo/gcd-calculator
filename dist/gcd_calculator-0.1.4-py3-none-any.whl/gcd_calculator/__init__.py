from gcd_calculator import gcd

__all__ = ['gcd']