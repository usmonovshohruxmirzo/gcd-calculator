from gcd_calculator.gcd import gcd

result = gcd(10, 10)
print(f"The GCD of 10 and 10 is: {result}")
